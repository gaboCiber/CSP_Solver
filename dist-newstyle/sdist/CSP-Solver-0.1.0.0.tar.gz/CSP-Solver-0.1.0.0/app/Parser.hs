module Parser where

import Text.Megaparsec
import Text.Megaparsec.Char
import qualified Data.Text as T
import Data.Void
import CSP  -- Importamos el módulo CSP para usar `Variable`

type Parser = Parsec Void String  -- Definimos nuestro tipo de parser

-- Parser para una variable
variableParser :: Parser Variable
variableParser = do
  first <- letterChar  -- Primer carácter debe ser una letra
  rest <- many (letterChar <|> digitChar <|> char '_')  -- Luego puede haber más letras, números o '_'
  return (first : rest)

-- Función auxiliar para ejecutar el parser
parseVariable :: String -> Either (ParseErrorBundle String Void) Variable
parseVariable = parse variableParser "variable"
